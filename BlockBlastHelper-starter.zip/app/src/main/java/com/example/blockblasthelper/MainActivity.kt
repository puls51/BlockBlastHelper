package com.example.blockblasthelper

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(16, 22, 34))
        }

        val title = TextView(this).apply {
            text = "Block Blast Helper"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val intro = TextView(this).apply {
            text = "\nПомощник для поиска удачных ходов.\n\nЭта сборка — техническая основа приложения. Распознавание поля по экрану и плавающие подсказки будут добавлены следующим этапом."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(intro, matchWrap())

        status = TextView(this).apply {
            text = "\nСтатус: приложение установлено и запущено."
            textSize = 15f
            setTextColor(Color.rgb(120, 220, 160))
            gravity = Gravity.CENTER
        }
        root.addView(status, matchWrap())

        val button = Button(this).apply {
            text = "Проверить приложение"
            setOnClickListener {
                status.text = "Статус: всё работает. Следующий этап — захват экрана и распознавание фигур."
            }
        }
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 28 }
        root.addView(button, params)

        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
